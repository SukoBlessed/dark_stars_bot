const {Client, IntentsBitField } = require('discord.js');
const client = new Client({
intents: [
IntentsBitField.Flags.Guilds,
IntentsBitField.Flags.GuildMembers, IntentsBitField.Flags.GuildMessages, IntentsBitField.Flags.MessageContent,
],
});
client.login(
  'MTI2NzgxMTE4MjYwNjAyNDcyNQ.GcOrFi.EsFKtqQk_0qVSa6e6Genjt2oeawJOjH5AbfWtA'
  );